public class day {

    String date;
    double open;
    double high;
    double low;
    double close;

    day(String date, double open, double high, double low, double close){
        this.date = date;
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
    }
}
