public class day {

    String date;
    double open;
    double close;

    day(String date, double open, double close){
        this.date = date;
        this.open = open;
        this.close = close;
    }
}
